from django.contrib import admin
from .models import *


admin.site.register(policeModel)
admin.site.register(User)
admin.site.register(criminalModel)
admin.site.register(crimModel)


