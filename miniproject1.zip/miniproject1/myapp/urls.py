from django.urls import path
from . import views
urlpatterns = [
    path('', views.home,name = "home"),
    path('signin',views.signin,name="signin"),
    path('signup',views.signup,name="signin"),
    path('logout',views.logout,name="logout"),
    path('classify',views.classify,name="classify"),
    path('detect_object',views.detect_object,name="detect_object"),
    path('handlefile',views.handlefile,name="handlefile")

]
