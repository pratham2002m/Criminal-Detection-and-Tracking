from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.http import JsonResponse
import os
from django.views.decorators.csrf import csrf_exempt
import json
import cv2
import numpy as np
from django.core.files.storage import FileSystemStorage
from keras.models import load_model
import pyrebase

firebaseConfig = {
    'apiKey': "AIzaSyAiorN1TVkPrA4drNDWg_ebgxIVKeENtmQ",
    'authDomain': "greengrocer-doctor-41b14.firebaseapp.com",
    'projectId': "greengrocer-doctor-41b14",
    'storageBucket': "greengrocer-doctor-41b14.appspot.com",
    'messagingSenderId': "785322440683",
    'appId': "1:785322440683:web:11ae92a66a2acb952d4bae",
    'measurementId': "G-HZQ30HEJ5N",
    "databaseURL": ""
  }


firebase=pyrebase.initialize_app(firebaseConfig)
authe = firebase.auth()
database = firebase.database()

# Create your views here.
def signin(request):
    data = json.loads(request.body)
    email = data['email']
    password = data['password']
    print(email,password)
    try:
        # if there is no error then signin the user with given email and password
        user=authe.sign_in_with_email_and_password(email,password)
    except:
        message="Invalid Credentials!!Please ChecK your Data"
        return JsonResponse({'message':message})
    session_id=user['idToken']
    request.session['uid']=str(session_id)
    # return render(request,"Home.html",{"email":email})

    return JsonResponse({"status":"success","email":email,"sessionId":session_id})

@csrf_exempt
def signup(request):
    data = json.loads(request.body)
    name = data["name"]
    username = data["username"]
    email = data["email"]
    password = data["password"]
    try:
        user = authe.create_user_with_email_and_password(email,password)

    except:
        message="Unable to Register! Internal Server Error"
        return JsonResponse({'message':message})

   
    uid = user['localId']
    data = {"name":name,"username":username,"email":email,"status":"1"}
    database.child("https://greengrocer-doctor-41b14-default-rtdb.firebaseio.com").child("users").child(uid).child("details").set(data)
    return JsonResponse({"status":"success","email":email,"password":password})
    return HttpResponse("Signup Request arrived!!")

def logout(request):
    return HttpResponse("Logout Request arrived!!")

def home(request):

    print("request arrived!")
    return render(request,'index.html')

@csrf_exempt
def classify(request):

    
    if len(request.FILES)!=0:
        try:
            myfile = request.FILES['myfile']
            print(myfile)

            print("processing the image....")
            class_names = ["Apple Bad", "Apple Good", "Apple mixed", "Banana Bad","Banana Good","Banana Mixed","Guava Bad","Guava Good","Guava Mixed","Lemon Mixed","Lime Bad","Lime Good","Orange Bad","Orange Good","Orange Mixed","Pomegranate Bad","Pomegranate Good","Pomegranate Mixed"] # fill the rest

            model = load_model("../keras/Indian Fruit_99.69.h5")
            
            img = cv2.imread("./static/FILES/result.jpg")
            if img is None:
                print("Incorrect path of image")

            else:
                img = cv2.resize(img,(224,224))
                img = np.reshape(img,[1,224,224,3])
                classes = np.argmax(model.predict(img), axis = -1)
                print(classes[0])
                ans = class_names[classes[0]]
            
            print(ans)

            if ans=="":
                return HttpResponse("File Not processed Properly!")
            else:
                myarr = ans.split(" ")
                response_data = {"FruitName":myarr[0],"Quality":myarr[1],"message":"Successfully Processed"}
                return JsonResponse(response_data)

            return HttpResponse("Request for image classification arrived!")
        except:
            message="Unable to process your request! Internal Server Error"
            return JsonResponse({'message':message})
        

    return JsonResponse({"message":"No Files uploaded!"})

def detect_object(request):
    

    return HttpResponse("Request for Object detection arrived!")


def handlefile(request):
    # print(len(request.FILES))
    # if len(request.FILES)!= 0:
    #     os.remove('./static/FILES/result.jpg')
    #     os.remove('./static/RESULT/result.jpg')
    #     folder='./static/FILES/'
    #     myfile = request.FILES['myfile']
    #     fs = FileSystemStorage(location=folder) #defaults to   MEDIA_ROOT  
    #     filename = fs.save("result.jpg", myfile)
    #     os.system('python ../yolov5/detect.py --weights ../yolov5/runs/train/exp/weights/best_fruit_quality.pt --img 640 --conf 0.25 --source ./static/FILES/result.jpg')
    #     print(filename)

    return HttpResponse("Request arrived for object detection!")
    # return render(request,'index.html')